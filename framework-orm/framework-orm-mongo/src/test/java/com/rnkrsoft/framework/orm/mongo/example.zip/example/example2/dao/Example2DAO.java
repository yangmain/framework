package com.rnkrsoft.framework.orm.mongo.example.example2.dao;

import com.rnkrsoft.framework.orm.mongo.MongoMapper;
import com.rnkrsoft.framework.orm.mongo.example.example2.entity.Example2Entity;


/**
 * Created by rnkrsoft.com on 2018/6/2.
 */
public interface Example2DAO extends MongoMapper<Example2Entity> {

}
