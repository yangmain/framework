package com.rnkrsoft.framework.orm.mongo.example.example1.dao;

import com.rnkrsoft.framework.orm.mongo.MongoMapper;
import com.rnkrsoft.framework.orm.mongo.example.example1.entity.Example1Entity;


/**
 * Created by rnkrsoft.com on 2018/6/2.
 */
public interface Example1DAO extends MongoMapper<Example1Entity> {

}
