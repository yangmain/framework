package com.rnkrsoft.framework.orm.mongo.example.example3.dao;

import com.rnkrsoft.framework.orm.mongo.MongoMapper;
import com.rnkrsoft.framework.orm.mongo.example.example3.entity.Example3Entity;


/**
 * Created by rnkrsoft.com on 2018/6/2.
 */
public interface Example3DAO extends MongoMapper<Example3Entity> {

}
